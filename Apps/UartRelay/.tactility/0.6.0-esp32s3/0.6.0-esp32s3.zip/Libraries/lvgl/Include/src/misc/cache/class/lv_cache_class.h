/**
 * @file lv_cache_clazz.h
 *
 */

#ifndef LV_CACHE_CLAZZ_H
#define LV_CACHE_CLAZZ_H


/*********************
 *      INCLUDES
 *********************/

#include "lv_cache_lru_rb.h"
#include "lv_cache_lru_ll.h"

#endif //LV_CACHE_CLAZZ_H
