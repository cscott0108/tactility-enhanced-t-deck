/**
 * @file lv_cache_instance.h
 *
 */

#ifndef LV_CACHE_INSTANCE_H
#define LV_CACHE_INSTANCE_H

/*********************
 *      INCLUDES
 *********************/

#include "lv_image_header_cache.h"
#include "lv_image_cache.h"

#endif //LV_CACHE_INSTANCE_H
